<!DOCTYPE html>
<html>
	<?php echo $__env->make('backend.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<body class="hold-transition sidebar-mini layout-fixed">
		<div class="wrapper">
			<?php echo $__env->make('backend.include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('backend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="content-wrapper">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
			<?php echo $__env->make('backend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<?php echo $__env->make('backend.include.footer-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('adminjsContent'); ?>
	</body>
</html><?php /**PATH E:\KMProject\nifticals\resources\views/backend/app.blade.php ENDPATH**/ ?>