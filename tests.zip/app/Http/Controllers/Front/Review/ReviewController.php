<?php

namespace App\Http\Controllers\Front\Review;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\ReviewModel;

class ReviewController extends Controller
{
    public function index(Request $request)
    {
        $reviewQuery = ReviewModel::insert([
                                            'product_id' => $_GET['review_product_id'], 
                                            'review_start_count' => $_GET['review_star_count'], 
                                            'customer_name' => $_GET['review_star_name'], 
                                            'customer_msg' => $_GET['review_star_msg'], 
                                            'created_at' => date('Y-m-d'), 
                                            'updated_at' => date('Y-m-d')
                                            ]);
        if($reviewQuery)
        {
            $msg = "success";
        }
        else
        {
            $msg = "error";
        }
        echo json_encode($msg);
    }
}
